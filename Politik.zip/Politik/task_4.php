<?php include 'inc/header.php'; ?>

<?php
echo "Clicking the -Task 4- button again, will show 5 different councillors again";
echo "<br><br> !!! IMPORTANT !!! I had an idea how to solve the Task 4, but with the Task 3 failing, I said I'll -modify- a bit this task, so instead of reading from the API, I read again from the councillors.json, I was able to complete the task this way. I'm not sure if it helps, but I think it's better to solve it in a different way, then not solving it at all. :) Right?<br><br>";
    $data = file_get_contents("contents/councillors.json");
    $data = json_decode($data, true); //true to convert them into Arrays

/* Here I save all the id's in the array[], to later use the length of the array[] to generate a random number.*/
foreach($data as $row){

    $array[] = $row['id'];

}

echo '<table class="table table-hover">';
for($i = 1; $i <= 5; $i++){

    /* here I take the 1 item, using the rand function, encoding it then decoding it to be able to display
     */
    $one_item = $data[rand(1, count($array)-1)];
    $one_item_encoded = json_encode($one_item);
    $row = json_decode($one_item_encoded, true); //true to convert them into Arrays

    echo'<tr class="table-active"><td>'.
        $row["firstName"].
        " ".$row["lastName"].
        " id: ".$row["id"].
        " updated: ".$row["updated"].
        " active: ".$row["active"].
        " code: ".$row["code"].
        " number: ".$row["number"].
        " officialDenomination: ".$row["officialDenomination"].
        " salutationLetter: ".$row["salutationLetter"].
        " salutationTitle: ".$row["salutationTitle"].
        '</td></tr>';
}
echo '</table>';
?>

<?php include 'inc/footer.php'; ?>




