<?php include_once 'config/init.php'; ?>

<!doctype html>
<html lang="en">
<head>
    <title>Councillors - Politik.ch</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<div class="container-xl">
    <div class="header clearfix">
        <nav>
            <ul class="nav nav-pills float-right">
                <li class="nav-item">
                    <a class="nav-link active" href="index.php"> Task 1 & Task 2 <span class="sr-only"></span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="task_3.php"> Task 3 <span class="sr-only"></span></a>
                </li>

                <li class="nav-item">
                    <a class="nav-link active" href="task_4.php"> Task 4 - Show 5 random <span class="sr-only"></span></a>
                </li>
            </ul>
        </nav>
        <h3 class="text-muted"><?php echo SITE_TITLE; ?></h3>
    </div>