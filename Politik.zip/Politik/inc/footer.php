<footer class="footer">
    <p>&copy; Councillors - Politik.ch</p>
</footer>

</div> <!-- /container -->
</body>
</html>