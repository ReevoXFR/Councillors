<?php include 'inc/header.php'; ?>

<?php

/* This is a little bit of a mess, in the comments you can see SOME of the things
I tried, I deleted a lot. */

echo "<br><br> This is all I could manage to read from the API, you can see in the task_3.php comments what I tried, I didn't manage to retrieve them correctly so I could place them in a table.";
echo "<br><br> Not sure if it has something to do with the error that I was getting from the website, you can see it inside /contents/error.png";
echo "<br><br> !!! IMPORTANT !!! I had an idea how to solve the Task 4, but with the Task 3 failing, I said I'll -modify- a bit that task, so instead of reading from the API, I read again from the councillors.json, I was able to complete the task this way. I'm not sure if it helps, but I think it's better to solve it in a different way, then not solving it at all. :) Right?<br><br>";
//$curl = curl_init();
//
//curl_setopt_array($curl,[
//    CURLOPT_RETURNTRANSFER => 1,
//    CURLOPT_URL => 'http://ws-old.parlament.ch/councillors?entryDateFilter=2018/12/31&format=xml&pageNumber=2',
//    CURLOPT_USERAGENT => 'Parlament.ch API in cURL'
//]);
//
//$response = curl_exec($curl);
//
//echo $response;
//
//curl_close($curl);

//$xml = new SimpleXMLElement('http://ws-old.parlament.ch/councillors?entryDateFilter=2018/12/31&format=xml&pageNumber=1'.$_GET['firstName'], 0, TRUE);

$url = 'http://ws-old.parlament.ch/councillors?entryDateFilter=2018/12/31&format=xml&pageNumber=3';
$councillors = simplexml_load_string($response, 'SimpleXMLElement', LIBXML_NOCDATA);
$councillors = new SimpleXMLElement('http://ws-old.parlament.ch/councillors?entryDateFilter=2018/12/31&format=xml&pageNumber=3', 0, TRUE);
foreach ($councillors as $book) {
    print_r($book->object->firstName);
    echo"<BR><BR><BR>";

}

print_r($councillors);
exit;

//$xml = simplexml_load_file($url);
//print_r($xml->councillors);
//exit;
//$p = xml_parser_create();
//xml_parse_into_struct($p, $file, $vals, $index);
//print_r($p);
//print_r($vals);
//echo "<table>
//  <thead>
//    <tr>
//      <th>Name</th>
//      <th>Call Sign</th>
//      <th>Type</th>
//      <th>Status</th>
//      <th>Expiration Date</th>
//    </tr>
//  </thead>
//  <tbody>";
//
//
//foreach ($xml->Licenses->License as $licenseElement) {
//    echo "
//<tr>
//      <td> $licenseElement->licName </td>
//    </tr>";
//}
//
// echo"</tbody>
//</table>";




//print_r($file);
//
//foreach ($file->id  as $cons):
//    echo $cons->firstName;
//endforeach;















?>

<?php include 'inc/footer.php'; ?>




