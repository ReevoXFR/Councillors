<?php include 'inc/header.php'; ?>

<table class="table table-hover">

<?php
/* Retrieving the data from the councillors.json */
    $data = file_get_contents("contents/councillors.json");
    $data = json_decode($data, true); //true to convert them into Arrays
    usort($data, function($a, $b){
        return strnatcasecmp($a['firstName'],$b['firstName']);
    });

/* Sorting by the firstName */
echo "First list sorted by firstName: <br> (scroll down for the second sort!)";
foreach($data as $row){
    echo'<tr class="table-active"><td>'.
        $row["firstName"].
        " ".$row["lastName"].
        " id: ".$row["id"].
        " updated: ".$row["updated"].
        " active: ".$row["active"].
        " code: ".$row["code"].
        " number: ".$row["number"].
        " officialDenomination: ".$row["officialDenomination"].
        " salutationLetter: ".$row["salutationLetter"].
        " salutationTitle: ".$row["salutationTitle"].
        '</td></tr>';
}
?>
</table>

    <table class="table table-hover">
        <?php
        $data = file_get_contents("contents/councillors.json");
        $data = json_decode($data, true); //true to convert them into Arrays
        usort($data, function($a, $b){
            return strnatcasecmp($a['lastName'],$b['lastName']);
        });

/* Sorting by the lastName */
        echo "Second list sorted by lastName:";
        foreach($data as $row){
            echo'<tr class=""><td>'.
                $row["lastName"].
                " ".$row["firstName"].
                " id: ".$row["id"].
                " updated: ".$row["updated"].
                " active: ".$row["active"].
                " code: ".$row["code"].
                " number: ".$row["number"].
                " officialDenomination: ".$row["officialDenomination"].
                " salutationLetter: ".$row["salutationLetter"].
                " salutationTitle: ".$row["salutationTitle"].
                '</td></tr>';
        }

        ?>
    </table>
<?php include 'inc/footer.php'; ?>